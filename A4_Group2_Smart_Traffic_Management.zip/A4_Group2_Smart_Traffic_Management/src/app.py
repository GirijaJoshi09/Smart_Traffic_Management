# from flask import Flask
# from dotenv import load_dotenv
# import os
# load_dotenv()

# app = Flask(__name__)

# # init db tables
# from src.db import init_db
# init_db()

# # register blueprints
# from src.routes.predictions import bp as pred_bp
# from src.routes.records import bp as rec_bp
# app.register_blueprint(pred_bp, url_prefix='/api')
# app.register_blueprint(rec_bp, url_prefix='/api')

# @app.route('/')
# def hello():
#     return {"msg":"Smart Traffic Management API - Lite version"}

# if __name__ == "__main__":
#     app.run(host='0.0.0.0', port=5000, debug=True)


from flask import Flask
from dotenv import load_dotenv
load_dotenv()

app = Flask(__name__, template_folder="../templates", static_folder="../static")

# init db
from db import init_db
init_db()

# API blueprints (already in your code)
from routes.predictions import bp as pred_bp
from routes.records import bp as rec_bp
app.register_blueprint(pred_bp, url_prefix="/api")
app.register_blueprint(rec_bp, url_prefix="/api")

# UI blueprint
from routes.dashboard import bp as ui_bp
app.register_blueprint(ui_bp)  # serves "/", "/dashboard" and the UI-only metrics APIs

@app.route("/health")
def health():
    return {"ok": True}

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)



