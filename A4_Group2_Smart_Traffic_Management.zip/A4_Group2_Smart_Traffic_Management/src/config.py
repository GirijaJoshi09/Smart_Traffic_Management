# import os
# from dotenv import load_dotenv

# # Load variables from .env file
# load_dotenv()

# class Config:
#     # Flask
#     SECRET_KEY = os.getenv('SECRET_KEY', 'supersecretkey')
#     FLASK_ENV = os.getenv('FLASK_ENV', 'development')
#     DEBUG = FLASK_ENV == 'development'

#     # Database
#     DB_HOST = os.getenv('DB_HOST', 'localhost')
#     DB_PORT = int(os.getenv('DB_PORT', 3306))
#     DB_USER = os.getenv('DB_USER', 'root')
#     DB_PASSWORD = os.getenv('DB_PASSWORD', '')
#     DB_NAME = os.getenv('DB_NAME', 'smart_traffic')

#     # Model directory
#     MODEL_DIR = os.getenv('MODEL_DIR', './models')

#     # Other settings (you can add more later)
#     ALLOWED_EX_
