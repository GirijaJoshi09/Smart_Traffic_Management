# import os
# import mysql.connector
# from mysql.connector import errorcode
# from dotenv import load_dotenv
# load_dotenv()

# print("🔍 Starting db.py...")

# DB_CONFIG = {
#     'host': os.getenv('DB_HOST', 'localhost'),
#     'port': int(os.getenv('DB_PORT', 3306)),
#     'user': os.getenv('DB_USER', 'root'),
#     'password': os.getenv('DB_PASSWORD', 'Girija@1234'),
#     'database': os.getenv('DB_NAME', 'smart_traffic'),
#     'autocommit': True
# }

# def get_conn():
#     print("⚙️ Connecting to MySQL...")
#     return mysql.connector.connect(**DB_CONFIG)

# def init_db():
#     print("🚀 init_db() called")
#     conn = get_conn()
#     cursor = conn.cursor()
#     print("✅ Connection successful, creating tables...")

#     cursor.execute("""
#     CREATE TABLE IF NOT EXISTS traffic_records (
#         id INT AUTO_INCREMENT PRIMARY KEY,
#         timestamp DATETIME,
#         location_id VARCHAR(100),
#         traffic_volume INT,
#         avg_vehicle_speed FLOAT,
#         vehicle_count_cars INT,
#         vehicle_count_trucks INT,
#         vehicle_count_bikes INT,
#         weather_condition VARCHAR(50),
#         temperature FLOAT,
#         humidity FLOAT,
#         accident_reported TINYINT(1),
#         created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
#     )
#     """)
#     # cursor.execute("""
#     # CREATE TABLE IF NOT EXISTS predictions (
#     #     id INT AUTO_INCREMENT PRIMARY KEY,
#     #     model_type VARCHAR(50),
#     #     location_id VARCHAR(100),
#     #     input_json JSON,
#     #     output_json JSON,
#     #     created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
#     # )
#     # """)

#     cursor.execute("""
#     CREATE TABLE IF NOT EXISTS predictions (
#         id INT AUTO_INCREMENT PRIMARY KEY,
#         model_type VARCHAR(50),
#         location_id VARCHAR(100),
#         input_json JSON,
#         output_json JSON,
#         emergency_flag TINYINT(1) DEFAULT 0,
#         emergency_source VARCHAR(128) DEFAULT NULL,
#         override_info JSON DEFAULT NULL,
#         created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
#     )
#     """)



#     conn.commit()
#     cursor.close()
#     conn.close()
#     print("✅ Database initialized successfully.")

# if __name__ == "__main__":
#     print("📢 Running db.py directly...")
#     init_db()



import os
import mysql.connector
from mysql.connector import errorcode
from dotenv import load_dotenv
load_dotenv()

print("🔍 Starting db.py...")

DB_CONFIG = {
    'host': os.getenv('DB_HOST', 'localhost'),
    'port': int(os.getenv('DB_PORT', 3306)),
    'user': os.getenv('DB_USER', 'root'),
    'password': os.getenv('DB_PASSWORD', 'Girija@1234'),
    'database': os.getenv('DB_NAME', 'smart_traffic'),
    'autocommit': True
}

def get_conn():
    print("⚙️ Connecting to MySQL...")
    return mysql.connector.connect(**DB_CONFIG)

def init_db():
    print("🚀 init_db() called")
    conn = get_conn()
    cursor = conn.cursor()
    print("✅ Connection successful, creating tables...")

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS traffic_records (
        id INT AUTO_INCREMENT PRIMARY KEY,
        timestamp DATETIME,
        location_id VARCHAR(100),
        traffic_volume INT,
        avg_vehicle_speed FLOAT,
        vehicle_count_cars INT,
        vehicle_count_trucks INT,
        vehicle_count_bikes INT,
        weather_condition VARCHAR(50),
        temperature FLOAT,
        humidity FLOAT,
        accident_reported TINYINT(1),
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )
    """)

    # UPDATED PREDICTIONS TABLE
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS predictions (
        id INT AUTO_INCREMENT PRIMARY KEY,
        model_type VARCHAR(50),
        location_id VARCHAR(100),
        input_json JSON,
        output_json JSON,
        emergency_flag TINYINT(1) DEFAULT 0,
        emergency_source VARCHAR(128) DEFAULT NULL,
        override_info JSON DEFAULT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )
    """)

    conn.commit()
    cursor.close()
    conn.close()
    print("✅ Database initialized successfully.")

if __name__ == "__main__":
    print("📢 Running db.py directly...")
    init_db()
