import os
import json
import numpy as np
from joblib import load
from dotenv import load_dotenv

load_dotenv()
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
MODEL_DIR = os.path.join(BASE_DIR, "models")


# -------------------------------------------------------------------
# Helper: Load model + metadata JSON
# -------------------------------------------------------------------
def load_model_and_meta(model_name):
    model_path = os.path.join(MODEL_DIR, f"{model_name}.joblib")
    meta_path = os.path.join(MODEL_DIR, f"{model_name}_meta.json")

    model = load(model_path)
    metadata = {}

    if os.path.exists(meta_path):
        with open(meta_path, "r") as f:
            metadata = json.load(f)

    return model, metadata

# def load_accident_model_and_enc():
#     model_path = os.path.join(MODEL_DIR, 'accident_model.joblib')
#     enc_path = os.path.join(MODEL_DIR, 'accident_enc.joblib')

#     model = load(model_path)
#     enc = None
#     if os.path.exists(enc_path):
#         enc = load(enc_path)
#     return model, enc
def load_accident_model_and_enc():
    model = load(os.path.join(MODEL_DIR, "accident_model.joblib"))
    enc = load(os.path.join(MODEL_DIR, "accident_enc.joblib"))
    return model, enc


# -------------------------------------------------------------------
# Confidence Calculators
# -------------------------------------------------------------------
def classification_confidence(prob_array):
    """
    prob_array: 1D array from predict_proba (for a single sample)
    """
    top_prob = float(np.max(prob_array))   # highest probability
    return top_prob


# def regression_confidence(pred, metadata):
#     """
#     For regression models: use stored MAE as uncertainty measure.
#     Heuristic confidence = 1 - (MAE / (MAE * k)) → around 60–90%
#     """
#     mae = metadata.get("mae", None)
#     if mae is None or mae == 0:
#         return 0.50   # fallback

#     # A conservative heuristic
#     k = 3  
#     conf = max(0.0, min(1.0, 1.0 - (mae / (mae * k))))
#     return float(conf)

# def regression_confidence(pred, metadata):
#     r2 = metadata.get("r2", None)

#     if r2 is None:
#         return 0.50   # fallback if missing

#     # R² is already a 0–1 score
#     conf = max(0.0, min(1.0, r2))
#     return float(conf)

def regression_confidence(pred, metadata):
    """
    Confidence = 1 - (|error_estimate| / (|error_estimate| + mae))
    This varies for each prediction.
    """

    mae = metadata.get("mae", None)
    if mae is None or mae == 0:
        return 0.50

    # Estimate error using prediction magnitude
    error_estimate = abs(pred) * 0.10  # assume ±10% uncertainty

    conf = 1 - (error_estimate / (error_estimate + mae))
    return float(max(0.0, min(1.0, conf)))

# -------------------------------------------------------------------
# Unified Prediction + Confidence
# -------------------------------------------------------------------
def predict_with_confidence(model_name, X):
    """
    X must be shaped as: [[feature1, feature2, ...]]
    Returns dictionary:
    {
        "prediction": value,
        "confidence": 0.0 to 1.0,
        "meta": { ... }
    }
    """

    model, metadata = load_model_and_meta(model_name)

    # ------------------------------
    # Classification models
    # ------------------------------
    if metadata.get("type") == "classification":
        prob = model.predict_proba(X)[0]
        pred = int(model.predict(X)[0])
        conf = classification_confidence(prob)

        return {
            "prediction": pred,
            "confidence": conf,
            "meta": metadata
        }

    # ------------------------------
    # Regression models
    # ------------------------------
    if metadata.get("type") == "regression":
        pred = float(model.predict(X)[0])
        conf = regression_confidence(pred, metadata)

        return {
            "prediction": pred,
            "confidence": conf,
            "meta": metadata
        }

    # fallback
    return {
        "prediction": float(model.predict(X)[0]),
        "confidence": metadata.get("accuracy", 0.50),
        "meta": metadata
    }


# -------------------------------------------------------------------
# MODEL LOADERS (for backward compatibility)
# -------------------------------------------------------------------
def load_signal_model():
    return load(os.path.join(MODEL_DIR, 'signal_time_model.joblib'))

def load_flow_model():
    return load(os.path.join(MODEL_DIR, 'vehicle_flow_model.joblib'))

def load_accident_model_and_enc():
    return load(os.path.join(MODEL_DIR, 'accident_model.joblib'))



# -------------------------------------------------------------------
# OLD PREDICT FUNCTIONS → Now they use predict_with_confidence internally
# -------------------------------------------------------------------

def predict_signal(payload):
    X = [[
        payload.get('traffic_volume', 0),
        payload.get('avg_vehicle_speed', 0),
        payload.get('vehicle_count_cars', 0),
        payload.get('vehicle_count_trucks', 0),
        payload.get('vehicle_count_bikes', 0),
        payload.get('hour', 0)
    ]]
    print("SIGNAL → X passed to model =", X)

    result = predict_with_confidence("signal_time_model", X)

    # keep your original rule: min 5 seconds
    # result["prediction"] = float(max(5, result["prediction"]))
    result["prediction"] = float(result["prediction"])

    return result


def predict_flow(payload):
    X = [[
        payload.get('traffic_volume', 0),
        payload.get('avg_vehicle_speed', 0),
        payload.get('temperature', 0),
        payload.get('humidity', 0),
        payload.get('hour', 0)
    ]]
    print("FLOW → X passed to model =", X)

    result = predict_with_confidence("vehicle_flow_model", X)

    # your original rounding logic
    # result["prediction"] = int(max(0, round(result["prediction"])))
    result["prediction"] = int(round(result["prediction"]))

    return result


# def predict_accident(payload):
#     model, enc = load_accident_model_and_enc()

#     num = [
#         payload.get('traffic_volume', 0),
#         payload.get('avg_vehicle_speed', 0),
#         payload.get('vehicle_count_cars', 0),
#         payload.get('temperature', 0),
#         payload.get('humidity', 0),
#         payload.get('hour', 0)
#     ]

#     weather = [[payload.get('weather_condition', 'Unknown')]]
#     weather_enc = enc.transform(weather)

#     X = np.hstack([np.array(num).reshape(1, -1), weather_enc])

#     result = predict_with_confidence("accident_model", X)

#     # interpret probability into risk levels
#     p = result["confidence"]   # classification_confidence gives top prob

#     risk = "High" if p >= 0.66 else ("Medium" if p >= 0.33 else "Low")

#     return {
#         "probability": float(p),
#         "risk_level": risk,
#         "confidence": float(p),     # same thing for classification
#         "meta": result["meta"]
#     }
# def predict_accident(payload):
#     model, enc = load_accident_model_and_enc()

#     # numeric features
#     num = [
#         payload.get('traffic_volume', 0),
#         payload.get('avg_vehicle_speed', 0),
#         payload.get('vehicle_count_cars', 0),
#         payload.get('temperature', 0),
#         payload.get('humidity', 0),
#         payload.get('hour', 0)
#     ]

#     # handle encoder
#     weather = [[payload.get('weather_condition', 'Unknown')]]
#     if enc is None:
#         # if no encoder saved, try to create a default one (rare)
#         from sklearn.preprocessing import OneHotEncoder
#         enc = OneHotEncoder(handle_unknown='ignore', sparse_output=False)
#         weather_enc = enc.fit_transform(weather)
#     else:
#         weather_enc = enc.transform(weather)

#     X = np.hstack([np.array(num).reshape(1, -1), weather_enc])

#     # probability of class '1' (accident)
#     probs = model.predict_proba(X)[0]
#     # If binary, class index for '1' might be model.classes_.tolist().index(1)
#     try:
#         idx_for_one = list(model.classes_).index(1)
#     except ValueError:
#         # fallback: assume positive class is the last class
#         idx_for_one = -1

#     prob_accident = float(probs[idx_for_one])
#     # confidence = max(prob_accident, 1 - prob_accident)
#     confidence = float(max(prob_accident, 1.0 - prob_accident))

#     risk = "High" if prob_accident >= 0.7 else ("Medium" if prob_accident >= 0.3 else "Low")

#     return {
#         "probability": prob_accident,
#         "risk": risk,
#         "confidence": round(confidence * 100, 2),
#         # include meta (if you want frontend to show accuracy, load metadata)
#         "meta": load_model_and_meta("accident_model")[1]
#     }
def predict_accident(payload):
    model, enc = load_accident_model_and_enc()

    num = [
        payload.get("traffic_volume", 0),
        payload.get("avg_vehicle_speed", 0),
        payload.get("vehicle_count_cars", 0),
        payload.get("temperature", 0),
        payload.get("humidity", 0),
        payload.get("hour", 0)
    ]

    weather = [[payload.get("weather_condition", "Unknown")]]
    weather_enc = enc.transform(weather)

    X = np.hstack([np.array(num).reshape(1, -1), weather_enc])

    probs = model.predict_proba(X)[0]

    # probability that accident = 1
    idx = list(model.classes_).index(1)
    p_acc = float(probs[idx])

    confidence = max(p_acc, 1 - p_acc)

    risk = "High" if p_acc >= 0.7 else "Medium" if p_acc >= 0.3 else "Low"

    meta = load_model_and_meta("accident_model")[1]

    return {
        "probability": p_acc,
        "confidence": confidence,
        "risk": risk,
        "meta": meta
    }
