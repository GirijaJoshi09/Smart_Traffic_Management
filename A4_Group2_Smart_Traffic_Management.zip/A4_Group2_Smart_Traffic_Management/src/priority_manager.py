# src/priority_manager.py

# def apply_emergency_priority(prediction, emergency=None, config=None):
#     """
#     Apply a minimal emergency priority override to prediction.
#     - prediction: dict (must contain 'signal_time' in seconds, optional 'direction')
#     - emergency: dict or None, e.g. {'active': True, 'direction': 'N', 'source': 'ambulance_gps'}
#     - config: dict of tuning params, e.g. {'max_override':30, 'min_green':10, 'preempt_safe':True}
#     Returns: (adjusted_prediction, override_info_or_None)
#     """
#     if not emergency or not emergency.get('active'):
#         return prediction, None

#     cfg = config or {'max_override': 30, 'min_green': 10, 'preempt_safe': True}
#     em_dir = emergency.get('direction')  # optional
#     pred_dir = prediction.get('direction')

#     # Only modify prediction for the direction of emergency if direction is provided
#     if pred_dir and em_dir and pred_dir != em_dir:
#         return prediction, None

#     try:
#         base = float(prediction.get('signal_time', 0))
#     except (TypeError, ValueError):
#         base = 0.0

#     # Safety: ensure base is at least min_green if less
#     if base < cfg['min_green']:
#         base = cfg['min_green']

#     # Add override but cap to max_override
#     add_seconds = cfg.get('max_override', 30)
#     new_signal = base + add_seconds

#     # Compose override_info for logging/audit
#     override_info = {
#         'was_overridden': True,
#         'old_signal': prediction.get('signal_time'),
#         'new_signal': new_signal,
#         'reason': 'emergency_priority',
#         'source': emergency.get('source') if emergency else None,
#         'direction': em_dir
#     }

#     # Update prediction in-place (or return a modified copy)
#     adjusted = prediction.copy()
#     adjusted['signal_time'] = new_signal
#     # Add note for traceability
#     notes = adjusted.get('notes', '')
#     adjusted['notes'] = (notes + ' | overridden_for_emergency').strip(' |')

#     return adjusted, override_info



def apply_emergency_priority(prediction, emergency=None, config=None):
    """
    Apply emergency override to the predicted signal time.
    Direction is NOT used in your project.
    """
    if not emergency or not emergency.get('active'):
        return prediction, None

    cfg = config or {'max_override': 30, 'min_green': 10}

    base = float(prediction.get("signal_time", 0) or 0)

    if base < cfg["min_green"]:
        base = cfg["min_green"]

    new_signal = base + cfg["max_override"]

    override_info = {
        "was_overridden": True,
        "old_signal": prediction.get("signal_time"),
        "new_signal": new_signal,
        "reason": "emergency_active",
        "source": emergency.get("source")
    }

    adjusted = prediction.copy()
    # adjusted["signal_time"] = new_signal
    adjusted['raw_value'] = new_signal
    adjusted['signal_time'] = new_signal
    adjusted['optimal_green_seconds'] = new_signal

    adjusted["notes"] = "Emergency override applied"

    return adjusted, override_info
