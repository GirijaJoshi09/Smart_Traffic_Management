# # src/routes/dashboard.py
# from flask import Blueprint, render_template, request, jsonify
# from db import get_conn

# bp = Blueprint("ui", __name__)

# @bp.route("/")
# @bp.route("/dashboard")
# def dashboard():
#     return render_template("dashboard.html")

# # ---- API helpers for charts (UI uses these) ----

# @bp.route("/api/metrics/traffic")
# def traffic_metrics():
#     """Return hourly volume for last N hours (default 24)."""
#     hours = int(request.args.get("hours", 24))
#     conn = get_conn()
#     cur = conn.cursor(dictionary=True)
#     cur.execute(f"""
#         SELECT DATE_FORMAT(timestamp, '%%Y-%%m-%%d %%H:00:00') AS hour_slot,
#                SUM(traffic_volume) AS total_volume,
#                AVG(avg_vehicle_speed) AS avg_speed
#         FROM traffic_records
#         WHERE timestamp >= NOW() - INTERVAL %s HOUR
#         GROUP BY hour_slot
#         ORDER BY hour_slot
#     """, (hours,))
#     rows = cur.fetchall()
#     cur.close(); conn.close()
#     return jsonify(rows)

# @bp.route("/api/metrics/predictions")
# def predictions_metrics():
#     """Return prediction counts. If no hours param → ALL data."""
#     hours_param = request.args.get("hours")

#     conn = get_conn()
#     cur = conn.cursor(dictionary=True)

#     # If ?hours=value → filter last N hours
#     if hours_param and hours_param != "all":
#         hours = int(hours_param)
#         cur.execute("""
#             SELECT model_type, COUNT(*) AS cnt
#             FROM predictions
#             WHERE created_at >= NOW() - INTERVAL %s HOUR
#             GROUP BY model_type
#             ORDER BY model_type
#         """, (hours,))
#     else:
#         # No filter → return ALL prediction records
#         cur.execute("""
#             SELECT model_type, COUNT(*) AS cnt
#             FROM predictions
#             GROUP BY model_type
#             ORDER BY model_type
#         """)

#     rows = cur.fetchall()
#     cur.close()
#     conn.close()
#     return jsonify(rows)

# @bp.route("/api/records/latest")
# def latest_records():
#     """Last 20 rows for table view."""
#     conn = get_conn()
#     cur = conn.cursor(dictionary=True)
#     cur.execute("SELECT * FROM traffic_records ORDER BY id DESC LIMIT 20")
#     rows = cur.fetchall()
#     cur.close(); conn.close()
#     return jsonify(rows)



# src/routes/dashboard.py
from flask import Blueprint, render_template, request, jsonify
from db import get_conn

bp = Blueprint("ui", __name__)

@bp.route("/")
@bp.route("/dashboard")
def dashboard():
    return render_template("dashboard.html")

# ---- API helpers for charts (UI uses these) ----

@bp.route("/api/metrics/traffic")
def traffic_metrics():
    """Return hourly volume for last N hours (default 24)."""
    hours = int(request.args.get("hours", 24))
    conn = get_conn()
    cur = conn.cursor(dictionary=True)
    cur.execute(f"""
        SELECT DATE_FORMAT(timestamp, '%%Y-%%m-%%d %%H:00:00') AS hour_slot,
               SUM(traffic_volume) AS total_volume,
               AVG(avg_vehicle_speed) AS avg_speed
        FROM traffic_records
        WHERE timestamp >= NOW() - INTERVAL %s HOUR
        GROUP BY hour_slot
        ORDER BY hour_slot
    """, (hours,))
    rows = cur.fetchall()
    cur.close(); conn.close()
    return jsonify(rows)

@bp.route("/api/metrics/predictions")
def predictions_metrics():
    """Return prediction counts. If no hours param → ALL data."""
    hours_param = request.args.get("hours")

    conn = get_conn()
    cur = conn.cursor(dictionary=True)

    # If ?hours=value → filter last N hours
    if hours_param and hours_param != "all":
        hours = int(hours_param)
        cur.execute("""
            SELECT model_type, COUNT(*) AS cnt
            FROM predictions
            WHERE created_at >= NOW() - INTERVAL %s HOUR
            GROUP BY model_type
            ORDER BY model_type
        """, (hours,))
    else:
        # No filter → return ALL prediction records
        cur.execute("""
            SELECT model_type, COUNT(*) AS cnt
            FROM predictions
            GROUP BY model_type
            ORDER BY model_type
        """)

    rows = cur.fetchall()
    cur.close()
    conn.close()
    return jsonify(rows)

@bp.route("/api/records/latest")
def latest_records():
    """Last 20 rows for table view."""
    conn = get_conn()
    cur = conn.cursor(dictionary=True)
    cur.execute("SELECT * FROM traffic_records ORDER BY id DESC LIMIT 20")
    rows = cur.fetchall()
    cur.close(); conn.close()
    return jsonify(rows)

@bp.route("/api/metrics/accident_intervals")
def accident_intervals():
    """Return accident counts grouped by hour and weather with optional filter."""
    mode = request.args.get("mode", "24h")   # default = last 24 hours

    conn = get_conn()
    cur = conn.cursor(dictionary=True)

    if mode == "all":
        query = """
            SELECT 
                HOUR(timestamp) AS hour_slot,
                weather_condition,
                SUM(accident_reported) AS accidents
            FROM traffic_records
            GROUP BY hour_slot, weather_condition
            ORDER BY hour_slot;
        """
        cur.execute(query)
    else:
        # last 24 hours
        query = """
            SELECT 
                HOUR(timestamp) AS hour_slot,
                weather_condition,
                SUM(accident_reported) AS accidents
            FROM traffic_records
            WHERE timestamp >= NOW() - INTERVAL 24 HOUR
            GROUP BY hour_slot, weather_condition
            ORDER BY hour_slot;
        """
        cur.execute(query)

    data = cur.fetchall()
    cur.close()
    conn.close()
    return jsonify(data)

