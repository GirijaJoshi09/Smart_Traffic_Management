from flask import Blueprint, request, jsonify
from models_helper import (
    predict_signal,
    predict_flow,
    predict_accident
)
from db import get_conn
import pandas as pd
from priority_manager import apply_emergency_priority

bp = Blueprint('predictions', __name__)


# ------------------ DB Helpers ---------------------
def json_str(obj):
    import json
    return json.dumps(obj)

# def log_prediction(model_type, location_id, input_data, output_data):
#     conn = get_conn()
#     cursor = conn.cursor()
#     cursor.execute(
#         "INSERT INTO predictions (model_type, location_id, input_json, output_json) "
#         "VALUES (%s, %s, %s, %s)",
#         (model_type, location_id, json_str(input_data), json_str(output_data))
#     )
#     cursor.close()
#     conn.close()

def log_prediction(model_type, location_id, input_data, output_data):
    conn = get_conn()
    cursor = conn.cursor()
    cursor.execute(
        """
        INSERT INTO predictions 
        (model_type, location_id, input_json, output_json, emergency_flag, emergency_source, override_info)
        VALUES (%s, %s, %s, %s, %s, %s, %s)
        """,
        (
            model_type,
            location_id,
            json_str(input_data),
            json_str(output_data),
            output_data.get("emergency_flag", 0),
            output_data.get("emergency_source"),
            json_str(output_data.get("override_info")) if output_data.get("override_info") else None
        )
    )
    cursor.close()
    conn.close()



# ------------------ Timestamp Helper ---------------------
def extract_hour(payload):
    if "timestamp" in payload:
        try:
            dt = pd.to_datetime(payload["timestamp"])
            payload["hour"] = int(dt.hour)
        except:
            payload["hour"] = payload.get("hour", 0)
    return payload


# --------------------------------------------------------
# SIGNAL PREDICTION
# --------------------------------------------------------
# @bp.route("/predict/signal", methods=["POST"])
# def predict_signal_route():
#     payload = extract_hour(request.get_json())

#     res = predict_signal(payload)   # <-- returns prediction + confidence + meta

#     output = {
#         "optimal_green_seconds": res["prediction"],
#         "signal_time": res["prediction"],
#         "raw_value": res["prediction"],
#         "confidence": round(res["confidence"] * 100, 2),
#         "metadata": res["meta"]
#     }

#     log_prediction("signal_time", payload.get("location_id", "unknown"), payload, output)
#     return jsonify({"success": True, "prediction": output})

@bp.route("/predict/signal", methods=["POST"])
def predict_signal_route():
    payload = extract_hour(request.get_json())

    # NEW: Emergency info coming from frontend/API
    # emergency = payload.get("emergency")
    emergency = payload.get("emergency", {})
    active = emergency.get("active") in [1, "1", True, "true"]
    emergency["active"] = active


    res = predict_signal(payload)   # <-- returns prediction + confidence + meta

    output = {
        "optimal_green_seconds": res["prediction"],
        "signal_time": res["prediction"],
        "raw_value": res["prediction"],
        "confidence": round(res["confidence"] * 100, 2),
        "metadata": res["meta"]
    }

    # NEW — APPLY EMERGENCY OVERRIDE HERE
    adjusted_output, override_info = apply_emergency_priority(
        output,
        emergency,
        config={"max_override": 30, "min_green": 10}
    )

    # NEW — Log with emergency fields
    log_prediction(
        "signal_time",
        payload.get("location_id", "unknown"),
        payload,
        {
            **adjusted_output,
            "emergency_flag": 1 if emergency and emergency.get("active") else 0,
            "emergency_source": emergency.get("source") if emergency else None,
            "override_info": override_info
        }
    )

    # return jsonify({"success": True, "prediction": adjusted_output})
    return jsonify({"success": True, "prediction": {
    **adjusted_output,
    }})


# --------------------------------------------------------
# VEHICLE FLOW (FIXED + CONFIDENCE + DEBUG)
# --------------------------------------------------------
@bp.route("/predict/flow", methods=["POST"])
def predict_flow_route():
    payload = extract_hour(request.get_json())

    print("\n📌 FLOW PAYLOAD RECEIVED:", payload)

    res = predict_flow(payload)

    print("📌 FLOW MODEL RESULT:", res)

    # output = {
    #     "predicted_next_interval_volume": res["prediction"],
    #     "flow_rate": res["prediction"],
    #     "raw_value": res["prediction"],
    #     # "confidence": round(res["confidence"] * 100, 2),
    #     "confidence": round(float(res.get("confidence", 0.50)) * 100, 2)
    #     "metadata": res["meta"]
    # }
    output = {
    "predicted_next_interval_volume": res["prediction"],
    "flow_rate": res["prediction"],
    "raw_value": res["prediction"],
    "confidence": round(float(res.get("confidence", 0.50)) * 100, 2),
    "metadata": res["meta"]
    }


    log_prediction("vehicle_flow", payload.get("location_id", "unknown"), payload, output)
    return jsonify({"success": True, "prediction": output})


# --------------------------------------------------------
# ACCIDENT PREDICTION (OK & WORKING)
# --------------------------------------------------------
@bp.route("/predict/accident", methods=["POST"])
def predict_accident_route():
    payload = extract_hour(request.get_json())

    res = predict_accident(payload)
    probability = res["probability"]

    if probability > 0.7:
        risk, risk_level = "High", "high"
    elif probability > 0.3:
        risk, risk_level = "Medium", "medium"
    else:
        risk, risk_level = "Low", "low"

    output = {
        "probability": probability,
        "risk": risk,
        "risk_level": risk_level,
        "raw_value": probability,
        "confidence": round(res["confidence"] * 100, 2),
        "metadata": res["meta"]
    }

    log_prediction("accident_risk", payload.get("location_id", "unknown"), payload, output)
    return jsonify({"success": True, "prediction": output})
