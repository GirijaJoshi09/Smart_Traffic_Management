from flask import Blueprint, request, jsonify
from db import get_conn

bp = Blueprint('records', __name__)

@bp.route('/records', methods=['GET', 'POST'])
def records():
    conn = get_conn()
    cursor = conn.cursor(dictionary=True)

    if request.method == 'POST':
        payload = request.get_json()
        cursor.execute("""
        INSERT INTO traffic_records (
            timestamp, location_id, traffic_volume, avg_vehicle_speed, 
            vehicle_count_cars, vehicle_count_trucks, vehicle_count_bikes, 
            weather_condition, temperature, humidity, accident_reported
        ) VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)
        """, (
            payload.get('timestamp'),
            payload.get('location_id'),
            payload.get('traffic_volume', 0),
            payload.get('avg_vehicle_speed', 0),
            payload.get('vehicle_count_cars', 0),
            payload.get('vehicle_count_trucks', 0),
            payload.get('vehicle_count_bikes', 0),
            payload.get('weather_condition'),
            payload.get('temperature'),
            payload.get('humidity'),
            int(payload.get('accident_reported', 0))
        ))
        conn.commit()
        cursor.close()
        conn.close()
        return jsonify({"success": True, "msg": "Record added"}), 201

    # GET method – fetch recent records
    cursor.execute("SELECT * FROM traffic_records ORDER BY id DESC LIMIT 10")
    records = cursor.fetchall()
    cursor.close()
    conn.close()
    return jsonify(records)
