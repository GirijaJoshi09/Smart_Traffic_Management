import os
import pandas as pd
import numpy as np
from sklearn.linear_model import LinearRegression, LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import OneHotEncoder
from joblib import dump
from dotenv import load_dotenv
# === NEW: helper to save model metadata ===
import json
from sklearn.metrics import mean_absolute_error, accuracy_score

def save_metadata(model_name, metadata):
    meta_path = os.path.join(MODEL_DIR, f"{model_name}_meta.json")
    with open(meta_path, "w") as f:
        json.dump(metadata, f, indent=2)
    print(f"📄 Saved metadata → {meta_path}")


load_dotenv()
MODEL_DIR = os.getenv('MODEL_DIR', './models')
os.makedirs(MODEL_DIR, exist_ok=True)

CSV_PATH = "data/traffic_sample.csv"

def load_and_prep(csv_path="data/traffic_sample.csv"):
    import pandas as pd
    df = pd.read_csv(csv_path)

    # ---- Handle timestamp ----
    if 'timestamp' in df.columns:
        df['timestamp'] = pd.to_datetime(df['timestamp'], errors='coerce')
        df['hour'] = df['timestamp'].dt.hour.fillna(0).astype(int)
    else:
        df['hour'] = 0  # fallback if no timestamp column

    # ---- Fill missing numeric values ----
    num_cols = df.select_dtypes(include=['float64', 'int64']).columns
    df[num_cols] = df[num_cols].fillna(0)

    # ---- Fill missing text values ----
    text_cols = df.select_dtypes(include=['object']).columns
    df[text_cols] = df[text_cols].fillna("Unknown")

    # ---- Ensure correct column names ----
    expected_cols = [
        'timestamp', 'location_id', 'traffic_volume', 'avg_vehicle_speed',
        'vehicle_count_cars', 'vehicle_count_trucks', 'vehicle_count_bikes',
        'weather_condition', 'temperature', 'humidity', 'accident_reported'
    ]
    missing = [c for c in expected_cols if c not in df.columns]
    if missing:
        print(f"⚠ Warning: Missing columns in dataset: {missing}")

    print("✅ Preprocessing complete.")
    print("Shape:", df.shape)
    print("Columns:", list(df.columns))
    print(df.head(5))

    return df

# def train_signal_time(df):
#     # Target: signal_time (you might need to compute from waiting time + heuristics)
#     # For demo, let's create a synthetic target: proportional to traffic_volume/avg_speed
#     df['signal_time'] = (df['traffic_volume'] / (df['avg_vehicle_speed'] + 1)) * 2
#     X = df[['traffic_volume', 'avg_vehicle_speed', 'vehicle_count_cars', 'vehicle_count_trucks', 'vehicle_count_bikes', 'hour']]
#     y = df['signal_time']
#     model = LinearRegression()
#     model.fit(X, y)
#     dump(model, os.path.join(MODEL_DIR, 'signal_time_model.joblib'))
#     print("Trained & saved signal_time_model")

# def train_signal_time(df):
#     # synthetic target
#     df['signal_time'] = (df['traffic_volume'] / (df['avg_vehicle_speed'] + 1)) * 2

#     X = df[['traffic_volume', 'avg_vehicle_speed', 'vehicle_count_cars',
#             'vehicle_count_trucks', 'vehicle_count_bikes', 'hour']]
#     y = df['signal_time']

#     # split for evaluation
#     X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

#     model = LinearRegression()
#     model.fit(X_train, y_train)

#     # save model
#     dump(model, os.path.join(MODEL_DIR, 'signal_time_model.joblib'))
#     print("Trained & saved signal_time_model")

#     # === NEW: compute MAE and save metadata ===
#     preds = model.predict(X_test)
#     mae = mean_absolute_error(y_test, preds)

#     metadata = {
#         "type": "regression",
#         "model_name": "signal_time_model",
#         "mae": float(mae)
#     }

#     save_metadata("signal_time_model", metadata)
# def train_signal_time(df):
#     # synthetic target
#     df['signal_time'] = (df['traffic_volume'] / (df['avg_vehicle_speed'] + 1)) * 2

#     X = df[['traffic_volume', 'avg_vehicle_speed', 'vehicle_count_cars',
#             'vehicle_count_trucks', 'vehicle_count_bikes', 'hour']]
#     y = df['signal_time']

#     # split for evaluation
#     X_train, X_test, y_train, y_test = train_test_split(
#         X, y, test_size=0.2, random_state=42
#     )

#     model = LinearRegression()
#     model.fit(X_train, y_train)

#     # save model
#     dump(model, os.path.join(MODEL_DIR, 'signal_time_model.joblib'))
#     print("Trained & saved signal_time_model")

#     # === NEW: compute MAE and save metadata ===
#     preds = model.predict(X_test)
#     mae = mean_absolute_error(y_test, preds)

#     metadata = {
#         "type": "regression",
#         "model_name": "signal_time_model",
#         "mae": float(mae)
#     }

#     save_metadata("signal_time_model", metadata)

def train_signal_time(df):
    from sklearn.metrics import mean_absolute_error, r2_score

    # synthetic target
    df['signal_time'] = (df['traffic_volume'] / (df['avg_vehicle_speed'] + 1)) * 2

    X = df[['traffic_volume', 'avg_vehicle_speed', 'vehicle_count_cars',
            'vehicle_count_trucks', 'vehicle_count_bikes', 'hour']]
    y = df['signal_time']

    # split for evaluation
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42
    )

    model = LinearRegression()
    model.fit(X_train, y_train)

    # save model
    dump(model, os.path.join(MODEL_DIR, 'signal_time_model.joblib'))
    print("Trained & saved signal_time_model")

    # === NEW: compute MAE + R² and save metadata ===
    preds = model.predict(X_test)
    mae = mean_absolute_error(y_test, preds)
    r2 = r2_score(y_test, preds)

    metadata = {
        "type": "regression",
        "model_name": "signal_time_model",
        "mae": float(mae),
        "r2": float(r2)
    }

    save_metadata("signal_time_model", metadata)


# def train_vehicle_flow(df):
#     # Predict traffic_volume next interval
#     # Create target: shift traffic_volume by -1 (next time)
#     df = df.sort_values(['location_id','timestamp'])
#     df['next_volume'] = df.groupby('location_id')['traffic_volume'].shift(-1).fillna(method='ffill')
#     X = df[['traffic_volume', 'avg_vehicle_speed', 'temperature', 'humidity', 'hour']]
#     y = df['next_volume']
#     model = LinearRegression()
#     # drop rows with NaN target
#     mask = ~y.isna()
#     model.fit(X[mask], y[mask])
#     dump(model, os.path.join(MODEL_DIR, 'vehicle_flow_model.joblib'))
#     print("Trained & saved vehicle_flow_model")

# def train_vehicle_flow(df):
#     df = df.sort_values(['location_id','timestamp'])
#     df['next_volume'] = df.groupby('location_id')['traffic_volume'].shift(-1).fillna(method='ffill')

#     X = df[['traffic_volume', 'avg_vehicle_speed', 'temperature', 'humidity', 'hour']]
#     y = df['next_volume']

#     mask = ~y.isna()
#     X = X[mask]
#     y = y[mask]

#     # split for evaluation
#     X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

#     model = LinearRegression()
#     model.fit(X_train, y_train)

#     dump(model, os.path.join(MODEL_DIR, 'vehicle_flow_model.joblib'))
#     print("Trained & saved vehicle_flow_model")

#     # === NEW: MAE metadata ===
#     preds = model.predict(X_test)
#     mae = mean_absolute_error(y_test, preds)

#     metadata = {
#         "type": "regression",
#         "model_name": "vehicle_flow_model",
#         "mae": float(mae)
#     }

#     save_metadata("vehicle_flow_model", metadata)
#     # Save metadata
#     meta = {
#         "type": "regression",
#         "mae": float(np.mean(np.abs(model.predict(X[mask]) - y[mask])))
#     }
#     with open(os.path.join(MODEL_DIR, "vehicle_flow_model_meta.json"), "w") as f:
#         json.dump(meta, f)

def train_vehicle_flow(df):
    from sklearn.metrics import mean_absolute_error, r2_score

    # Sort for next-interval prediction
    df = df.sort_values(['location_id', 'timestamp'])
    
    # Create target
    df['next_volume'] = df.groupby('location_id')['traffic_volume'].shift(-1)
    df['next_volume'] = df['next_volume'].ffill()   # new recommended way

    X = df[['traffic_volume', 'avg_vehicle_speed', 'temperature', 'humidity', 'hour']]
    y = df['next_volume']

    mask = ~y.isna()
    X = X[mask]
    y = y[mask]

    # Train-test split
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42
    )

    model = LinearRegression()
    model.fit(X_train, y_train)

    # Save model
    dump(model, os.path.join(MODEL_DIR, 'vehicle_flow_model.joblib'))
    print("Trained & saved vehicle_flow_model")

    # ---- Compute Errors ----
    preds = model.predict(X_test)
    mae = mean_absolute_error(y_test, preds)
    r2 = r2_score(y_test, preds)

    # ---- Save Metadata ----
    metadata = {
        "type": "regression",
        "model_name": "vehicle_flow_model",
        "mae": float(mae),
        "r2": float(r2)
    }

    save_metadata("vehicle_flow_model", metadata)


# def train_accident(df):
#     from imblearn.over_sampling import SMOTE
#     from sklearn.preprocessing import OneHotEncoder
#     from sklearn.linear_model import LogisticRegression
#     import numpy as np
#     import os
#     from joblib import dump

#     # Binary classification: accident_reported (0/1)
#     cat_cols = ['weather_condition']
#     enc = OneHotEncoder(handle_unknown='ignore', sparse_output=False)
#     cat_mat = enc.fit_transform(df[cat_cols])

#     num_cols = df[['traffic_volume','avg_vehicle_speed','vehicle_count_cars','temperature','humidity','hour']].values
#     X = np.hstack([num_cols, cat_mat])
#     y = df['accident_reported'].astype(int).values

#     # ✅ Handle label imbalance using SMOTE
#     print("🧮 Balancing accident_reported classes using SMOTE...")
#     smote = SMOTE(random_state=42)
#     X_balanced, y_balanced = smote.fit_resample(X, y)
#     print(f"Class distribution before: {np.bincount(y)}")
#     print(f"Class distribution after:  {np.bincount(y_balanced)}")

#     model = LogisticRegression(max_iter=200)
#     model.fit(X_balanced, y_balanced)

#     dump((model, enc), os.path.join(MODEL_DIR, 'accident_model.joblib'))
#     print("✅ Trained & saved balanced accident_model (with encoder)")

# def train_accident(df):
#     from imblearn.over_sampling import SMOTE
#     from sklearn.preprocessing import OneHotEncoder
#     from sklearn.linear_model import LogisticRegression
#     import numpy as np

#     cat_cols = ['weather_condition']
#     enc = OneHotEncoder(handle_unknown='ignore', sparse_output=False)
#     cat_mat = enc.fit_transform(df[cat_cols])

#     num_cols = df[['traffic_volume','avg_vehicle_speed','vehicle_count_cars',
#                    'temperature','humidity','hour']].values

#     X = np.hstack([num_cols, cat_mat])
#     y = df['accident_reported'].astype(int).values

#     print("🧮 Balancing accident_reported classes using SMOTE...")
#     smote = SMOTE(random_state=42)
#     X_balanced, y_balanced = smote.fit_resample(X, y)
#     print(f"Before: {np.bincount(y)}")
#     print(f"After:  {np.bincount(y_balanced)}")

#     # split for evaluation
#     X_train, X_test, y_train, y_test = train_test_split(
#         X_balanced, y_balanced, test_size=0.2, random_state=42
#     )

#     model = LogisticRegression(max_iter=200)
#     model.fit(X_train, y_train)

#     # Save model + encoder
#     dump((model, enc), os.path.join(MODEL_DIR, 'accident_model.joblib'))
#     print("✅ Trained & saved accident_model")

#     # === NEW: classification accuracy ===
#     preds = model.predict(X_test)
#     acc = accuracy_score(y_test, preds)

#     metadata = {
#         "type": "classification",
#         "model_name": "accident_model",
#         "accuracy": float(acc)
#     }

#     save_metadata("accident_model", metadata)
#     # Save metadata
#     meta = {
#         "type": "classification"
#     }
#     with open(os.path.join(MODEL_DIR, "accident_model_meta.json"), "w") as f:
#         json.dump(meta, f)
# def train_accident(df):
#     from imblearn.over_sampling import SMOTE
#     from sklearn.preprocessing import OneHotEncoder
#     from sklearn.linear_model import LogisticRegression
#     import numpy as np
#     from joblib import dump

#     cat_cols = ['weather_condition']
#     enc = OneHotEncoder(handle_unknown='ignore', sparse_output=False)
#     cat_mat = enc.fit_transform(df[cat_cols])

#     num_cols = df[['traffic_volume','avg_vehicle_speed','vehicle_count_cars',
#                    'temperature','humidity','hour']].values

#     X = np.hstack([num_cols, cat_mat])
#     y = df['accident_reported'].astype(int).values

#     print("🧮 Balancing accident_reported classes using SMOTE...")
#     smote = SMOTE(random_state=42)
#     X_balanced, y_balanced = smote.fit_resample(X, y)
#     print(f"Before: {np.bincount(y)}")
#     print(f"After:  {np.bincount(y_balanced)}")

#     # split for evaluation
#     X_train, X_test, y_train, y_test = train_test_split(
#         X_balanced, y_balanced, test_size=0.2, random_state=42
#     )

#     model = LogisticRegression(max_iter=500)
#     model.fit(X_train, y_train)

#     # --- SAVE model and encoder separately ---
#     dump(model, os.path.join(MODEL_DIR, 'accident_model.joblib'))
#     dump(enc, os.path.join(MODEL_DIR, 'accident_enc.joblib'))
#     print("✅ Trained & saved accident_model and accident_enc")

#     # === compute classification accuracy on held-out test set ===
#     preds = model.predict(X_test)
#     acc = accuracy_score(y_test, preds)

#     metadata = {
#         "type": "classification",
#         "model_name": "accident_model",
#         "accuracy": float(acc),
#         "classes": model.classes_.tolist()
#     }

#     # Save metadata JSON (uses your save_metadata helper)
#     save_metadata("accident_model", metadata)

# def train_accident(df):
#     from imblearn.over_sampling import SMOTE
#     from sklearn.preprocessing import OneHotEncoder
#     from sklearn.linear_model import LogisticRegression
#     from sklearn.metrics import accuracy_score
#     import numpy as np
#     from joblib import dump

#     # encode weather
#     enc = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
#     weather_enc = enc.fit_transform(df[['weather_condition']])

#     num = df[['traffic_volume', 'avg_vehicle_speed', 'vehicle_count_cars',
#               'temperature', 'humidity', 'hour']].values

#     X = np.hstack([num, weather_enc])
#     y = df['accident_reported'].astype(int).values

#     print("🧮 Applying SMOTE balancing...")
#     sm = SMOTE(random_state=42)
#     Xb, yb = sm.fit_resample(X, y)

#     X_train, X_test, y_train, y_test = train_test_split(
#         Xb, yb, test_size=0.2, random_state=42
#     )

#     model = LogisticRegression(max_iter=500)
#     model.fit(X_train, y_train)

#     # save separately
#     dump(model, os.path.join(MODEL_DIR, "accident_model.joblib"))
#     dump(enc, os.path.join(MODEL_DIR, "accident_enc.joblib"))
#     print("✅ Saved accident_model + encoder separately")

#     preds = model.predict(X_test)
#     acc = accuracy_score(y_test, preds)

#     metadata = {
#         "type": "classification",
#         "accuracy": float(acc),
#         "classes": model.classes_.tolist()
#     }

#     save_metadata("accident_model", metadata)

def train_accident(df):
    from imblearn.over_sampling import SMOTE
    from sklearn.preprocessing import OneHotEncoder
    from sklearn.linear_model import LogisticRegression
    from sklearn.metrics import accuracy_score
    import numpy as np

    cat_cols = ['weather_condition']
    enc = OneHotEncoder(handle_unknown='ignore', sparse_output=False)
    cat_mat = enc.fit_transform(df[cat_cols])

    num_cols = df[['traffic_volume','avg_vehicle_speed','vehicle_count_cars',
                   'temperature','humidity','hour']].values

    X = np.hstack([num_cols, cat_mat])
    y = df['accident_reported'].astype(int).values

    print("🧮 Balancing accident_reported classes using SMOTE...")
    smote = SMOTE(random_state=42)
    X_balanced, y_balanced = smote.fit_resample(X, y)
    print(f"Before: {np.bincount(y)}")
    print(f"After:  {np.bincount(y_balanced)}")

    # Train/test split
    X_train, X_test, y_train, y_test = train_test_split(
        X_balanced, y_balanced, test_size=0.2, random_state=42
    )

    model = LogisticRegression(max_iter=200)
    model.fit(X_train, y_train)

    # SAVE CORRECT FILE (MODEL + ENCODER TOGETHER)
    dump((model, enc), os.path.join(MODEL_DIR, 'accident_model.joblib'))
    print("✅ Trained & saved accident_model (model + encoder)")

    # Accuracy metadata
    preds = model.predict(X_test)
    acc = accuracy_score(y_test, preds)

    metadata = {
        "type": "classification",
        "model_name": "accident_model",
        "accuracy": float(acc)
    }

    save_metadata("accident_model", metadata)


def main():
    df = load_and_prep()
    train_signal_time(df)
    train_vehicle_flow(df)
    train_accident(df)
    print("All models trained.")

if __name__ == "__main__":
    main()
