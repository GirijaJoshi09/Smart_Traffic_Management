# small utilities you might need
import json
def safe_get(d,k,default=None):
    return d[k] if k in d else default
