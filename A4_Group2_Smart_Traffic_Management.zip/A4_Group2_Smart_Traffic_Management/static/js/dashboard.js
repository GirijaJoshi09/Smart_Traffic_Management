const tabs = document.querySelectorAll(".tab-btn");
let selectedMode = "signal"; // default tab

tabs.forEach(tab => {
  tab.addEventListener("click", () => {
    tabs.forEach(t => t.classList.remove("active"));
    tab.classList.add("active");
    selectedMode = tab.dataset.tab;
    document.getElementById("result").textContent = "";
  });
});

async function jget(url) {
  const r = await fetch(url);
  return await r.json();
}

async function jpost(url, body) {
  const r = await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body)
  });
  return await r.json();
}

document.getElementById("predict-form").addEventListener("submit", async e => {
  e.preventDefault();
  const payload = {
    timestamp: document.getElementById("timestamp").value,
    location_id: document.getElementById("location").value,
    traffic_volume: Number(document.getElementById("volume").value),
    avg_vehicle_speed: Number(document.getElementById("speed").value),
    vehicle_count_cars: Number(document.getElementById("cars").value),
    vehicle_count_trucks: Number(document.getElementById("trucks").value),
    vehicle_count_bikes: Number(document.getElementById("bikes").value),
    weather_condition: document.getElementById("weather").value,
    temperature: Number(document.getElementById("temp").value),
    humidity: Number(document.getElementById("humidity").value),
    accident_reported: Number(document.getElementById("accident").value)
  };

  const result = document.getElementById("result");
  result.textContent = "Processing...";

  try {
    let endpoint = "";
    if (selectedMode === "signal") endpoint = "/api/predict/signal";
    else if (selectedMode === "vehicle") endpoint = "/api/predict/flow";
    else endpoint = "/api/predict/accident";

    const res = await jpost(endpoint, payload);
    result.textContent = "✅ Prediction: " + JSON.stringify(res.prediction);
  } catch (err) {
    result.textContent = "❌ Error fetching prediction";
  }
});

// Load charts
async function loadCharts() {
  const volumeData = await jget("/api/metrics/traffic?hours=24");
  const predData = await jget("/api/metrics/predictions?hours=24");

  const ctx1 = document.getElementById("trafficVolumeChart").getContext("2d");
  const ctx2 = document.getElementById("predCountsChart").getContext("2d");

  new Chart(ctx1, {
    type: "line",
    data: {
      labels: volumeData.map(v => v.hour_slot),
      datasets: [{
        label: "Traffic Volume",
        data: volumeData.map(v => v.total_volume),
        borderColor: "#00ff99",
        backgroundColor: "rgba(0,255,153,0.1)",
        fill: true
      }]
    },
    options: { responsive: true, scales: { y: { beginAtZero: true } } }
  });

  new Chart(ctx2, {
    type: "bar",
    data: {
      labels: predData.map(p => p.model_type),
      datasets: [{
        label: "Predictions Count",
        data: predData.map(p => p.cnt),
        backgroundColor: ["#00ff99", "#ffaa00", "#ff3333"]
      }]
    },
    options: { responsive: true, scales: { y: { beginAtZero: true } } }
  });
}

document.addEventListener("DOMContentLoaded", loadCharts);
